import java.util.Random;

public class Deck {

	Card[] deck = new Card[52];
	Card joker = new Card(' ', 0, BlackJackConst.JOKER);
	private int nextCardIndex;
	public Deck(){

		int count = 0;
		try{
            for (int i = 0; i < BlackJackConst.SUIT.length; i++) {
            	for (int j = 1; j <= 13; j++) {
            		switch (j) {
            		case 1:
            			deck[count] = new Card(BlackJackConst.SUIT[i].charAt(0),j, 11, BlackJackConst.ACE+" of "+BlackJackConst.SUIT[i]);
            			deck[count].setSymbol(" |"+BlackJackConst.ACE.charAt(0)+BlackJackConst.SUIT[i].charAt(0)+"| ");
            			count++;
            			break;
            		case 2:
            			deck[count] = new Card(BlackJackConst.SUIT[i].charAt(0), j, BlackJackConst.TWO+" of "+BlackJackConst.SUIT[i]);
            			deck[count].setSymbol(" |"+j+BlackJackConst.SUIT[i].charAt(0)+"| ");
            			count++;
            			break;
            		case 3:
						 deck[count] = new Card(BlackJackConst.SUIT[i].charAt(0), j, BlackJackConst.THREE+" of "+BlackJackConst.SUIT[i]);
						 deck[count].setSymbol(" |"+j+BlackJackConst.SUIT[i].charAt(0)+"| ");
						 count++;
						break;
            		case 4:
						 deck[count] = new Card(BlackJackConst.SUIT[i].charAt(0), j, BlackJackConst.FOUR+" of "+BlackJackConst.SUIT[i]);
						 deck[count].setSymbol(" |"+j+BlackJackConst.SUIT[i].charAt(0)+"| ");
						 count++;
						break;
            		case 5:
						 deck[count] = new Card(BlackJackConst.SUIT[i].charAt(0), j, BlackJackConst.FIVE+" of "+BlackJackConst.SUIT[i]);
						 deck[count].setSymbol(" |"+j+BlackJackConst.SUIT[i].charAt(0)+"| ");
						 count++;
						break;
            		case 6:
						 deck[count] = new Card(BlackJackConst.SUIT[i].charAt(0), j, BlackJackConst.SIX+" of "+BlackJackConst.SUIT[i]);
						 deck[count].setSymbol(" |"+j+BlackJackConst.SUIT[i].charAt(0)+"| ");
						 count++;
						break;
            		case 7:
						 deck[count] = new Card(BlackJackConst.SUIT[i].charAt(0), j, BlackJackConst.SEVEN+" of "+BlackJackConst.SUIT[i]);
						 deck[count].setSymbol(" |"+j+BlackJackConst.SUIT[i].charAt(0)+"| ");
						 count++;
						break;
            		case 8:
						 deck[count] = new Card(BlackJackConst.SUIT[i].charAt(0), j, BlackJackConst.EIGHT+" of "+BlackJackConst.SUIT[i]);
						 deck[count].setSymbol(" |"+j+BlackJackConst.SUIT[i].charAt(0)+"| ");
						 count++;
						break;
            		case 9:
						 deck[count] = new Card(BlackJackConst.SUIT[i].charAt(0), j, BlackJackConst.NINE+" of "+BlackJackConst.SUIT[i]);
						 deck[count].setSymbol(" |"+j+BlackJackConst.SUIT[i].charAt(0)+"| ");
						 count++;
						break;
            		case 10:
						 deck[count] = new Card(BlackJackConst.SUIT[i].charAt(0), j, BlackJackConst.TEN+" of "+BlackJackConst.SUIT[i]);
						 deck[count].setSymbol(" |"+j+BlackJackConst.SUIT[i].charAt(0)+"| ");
						 count++;
						break;
            		case 11:
						 deck[count] = new Card(BlackJackConst.SUIT[i].charAt(0), 10, BlackJackConst.JACK+" of "+BlackJackConst.SUIT[i]);
						 deck[count].setSymbol(" |"+BlackJackConst.JACK.charAt(0)+BlackJackConst.SUIT[i].charAt(0)+"| ");
						 count++;
						break;
            		case 12:
						 deck[count] = new Card(BlackJackConst.SUIT[i].charAt(0), 10, BlackJackConst.QUEEN+" of "+BlackJackConst.SUIT[i]);
						 deck[count].setSymbol(" |"+BlackJackConst.QUEEN.charAt(0)+BlackJackConst.SUIT[i].charAt(0)+"| ");
						 count++;
						break;
            		case 13:
						 deck[count] = new Card(BlackJackConst.SUIT[i].charAt(0), 10, BlackJackConst.KING+" of "+BlackJackConst.SUIT[i]);
						 deck[count].setSymbol(" |"+BlackJackConst.KING.charAt(0)+BlackJackConst.SUIT[i].charAt(0)+"| ");
						 count++;
						break;


            		default:
            			break;
					}
            	}
				
			}
			
		}

		catch(Exception e){
			
			System.out.println("Error in creating Deck::");
			 e.printStackTrace();
		}
	}
	private void swapCards(int index1, int index2)  {	
		Card hold;

		boolean a = isIndexGood(index1);
		boolean b = isIndexGood(index2);
		
		if(a&&b) {
	       hold = deck[index1];
		   deck[index1] = deck[index2];
		   deck[index2] = hold;
		}
	}
	private boolean isIndexGood(int index){
		if (index >= 0 || index <= 51) {
			return true;
		}
		return false;
	}
	public void shuffle() {
		
		Random rand = new Random();
		int n = 26;
        for (int i = 0; i < n; i++){
            // Random for remaining positions.
            int r = i + rand.nextInt(52 - i);
            
            swapCards(i, r);
        }
	}
	public Card getCard(int index){
		if(isIndexGood(index)) {
		return deck[index];
		}
		return joker ;
	}
	public Card nextCard() {

		if (nextCardIndex < 0 || nextCardIndex > 51) {
			System.out.println("Error in getting next card");
			return joker ;
		}
		return deck[nextCardIndex++];
	}
	public void prinDeck() {
		
		for (int i =0; i < deck.length; i++) {
			
			System.out.println(deck[i].getSymbol());
		}
		
	}
	//testing deck
	/*
	public static void main(String[] args) {
		
		Deck d1 = new Deck();
		d1.shuffle();
		d1.prinDeck();
	}*/
}
