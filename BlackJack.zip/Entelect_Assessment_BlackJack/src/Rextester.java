import java.util.InputMismatchException;
import java.util.Scanner;

public class Rextester {

	private static Scanner ki = new Scanner(System.in);
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Welcome to Blackjack!");
		System.out.println("");
		System.out.println("  BLACKJACK RULES: ");
		System.out.println("	-Each player is dealt 2 cards.");
		System.out.println("	-Cards are equal to their value with face cards being 10 and an Ace being 1 or 11.");
		System.out.println("	-The players cards are added up for their total.");
		System.out.println("	-Players Hit? to gain another card from the deck. Players Stay to keep their current card total.");
		System.out.println("	-Dealer Hits? until they equal or exceed 17.");
		System.out.println("	-The goal is to have a higher card total than the dealer without going over 21.");
		System.out.println("	-If the player total equals the dealer total, player wins."); 
		System.out.println("    -If the player hand consist of 5 cards without exceding 21, player wins   ");
		System.out.println("");

		int input =0;
		
		try {
			 System.out.println("Please Enter 1 to Run test case or Enter 2 to Run Game? ");
			      

             if(ki.hasNextInt() ){
			    input = ki.nextInt();
			  }else {
				   do {  
					   System.out.println("Enterd invaild input ");
					   System.out.println("Please Enter 1 to Run test case or Enter 2 to Run Game? ");
				       input = ki.nextInt();
				   } while (input != 1 || input !=2);
			   }
			 
			}catch(Exception e){
				System.out.println("Error in getting user input, can not continue");
				e.printStackTrace();
				throw new InputMismatchException();
			}
		    
		    if (input == 1) {
		    	runTest();
			}else if(input == 2) {
				runGame();
			}else {
				System.out.println(" Game Ended something went wrong");
			}

	}
	
	public static void runTest() {
		Testcase mygame = new Testcase();
		
		mygame.initializeGame();
		mygame.dealCards();
		mygame.printHands();
		mygame.checkBlackjack();
		mygame.findWiners();
		System.out.println(" Test case ended Thank You");
	}
	
	public static void runGame() {
	 BlackJackGame mygame = new BlackJackGame();
	 
		mygame.initializeGame();
		//do {
			mygame.shuffle();
			mygame.dealCards();
			mygame.printHands();
			mygame.checkBlackjack();
			mygame.hitOrStand();
			mygame.dealerPlays();
			mygame.findWiners();
			mygame.clearHands();
		//} while (mygame.playAgain());
			System.out.println(" Thank You for playing");
	}

}
