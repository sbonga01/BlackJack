

public class Testcase {
    
	Card[] testDeck = new Card[16];
	private Player[] players =new Player[4];
	private Dealer dealer = new Dealer();
	
	public Testcase() {
		//spade =0 ; Diamond = 1 ; clubs = 2; heart = 3
		//creating test deck
		testDeck[0] = new Card(BlackJackConst.SUIT[0].charAt(0), 10, BlackJackConst.JACK+" of "+BlackJackConst.SUIT[0]);
		testDeck[0].setSymbol(" |"+BlackJackConst.JACK.charAt(0)+BlackJackConst.SUIT[0].charAt(0)+"| ");
		
		testDeck[1] = new Card(BlackJackConst.SUIT[3].charAt(0), 9, BlackJackConst.NINE+" of "+BlackJackConst.SUIT[3]);
		testDeck[1].setSymbol(" |"+testDeck[1].getValue()+testDeck[1].getSuit()+"| ");
		
		testDeck[2] = new Card(BlackJackConst.SUIT[0].charAt(0), 1, BlackJackConst.ACE+" of "+BlackJackConst.SUIT[0]);
		testDeck[2].setSymbol(" |"+BlackJackConst.ACE.charAt(0)+BlackJackConst.SUIT[0].charAt(0)+"| ");
		
		testDeck[3] = new Card(BlackJackConst.SUIT[3].charAt(0), 7, BlackJackConst.SEVEN+" of "+BlackJackConst.SUIT[3]);
		testDeck[3].setSymbol(" |"+testDeck[3].getValue()+testDeck[3].getSuit()+"| ");
		
		testDeck[4] = new Card(BlackJackConst.SUIT[1].charAt(0), 1, BlackJackConst.ACE+" of "+BlackJackConst.SUIT[1]);
		testDeck[4].setSymbol(" |"+BlackJackConst.ACE.charAt(0)+testDeck[4].getSuit()+"| ");
		
		testDeck[5] = new Card(BlackJackConst.SUIT[1].charAt(0), 10, BlackJackConst.KING+" of "+BlackJackConst.SUIT[1]);
		testDeck[5].setSymbol(" |"+BlackJackConst.KING.charAt(0)+testDeck[5].getSuit()+"| ");
		
		testDeck[6] = new Card(BlackJackConst.SUIT[0].charAt(0), 4, BlackJackConst.FOUR+" of "+BlackJackConst.SUIT[0]);
		testDeck[6].setSymbol(" |"+testDeck[6].getValue()+testDeck[6].getSuit()+"| ");
		
		testDeck[7] = new Card(BlackJackConst.SUIT[2].charAt(0), 4, BlackJackConst.FOUR+" of "+BlackJackConst.SUIT[2]);
		testDeck[7].setSymbol(" |"+testDeck[7].getValue()+testDeck[7].getSuit()+"| ");
		
		testDeck[8] = new Card(BlackJackConst.SUIT[0].charAt(0), 2, BlackJackConst.TWO+" of "+BlackJackConst.SUIT[0]);
		testDeck[8].setSymbol(" |"+testDeck[8].getValue()+testDeck[8].getSuit()+"| ");
		
		testDeck[9] = new Card(BlackJackConst.SUIT[1].charAt(0), 2, BlackJackConst.TWO+" of "+BlackJackConst.SUIT[1]);
		testDeck[9].setSymbol(" |"+testDeck[9].getValue()+testDeck[9].getSuit()+"| ");
		
		testDeck[10] = new Card(BlackJackConst.SUIT[3].charAt(0), 2, BlackJackConst.TWO+" of "+BlackJackConst.SUIT[3]);
		testDeck[10].setSymbol(" |"+testDeck[10].getValue()+testDeck[10].getSuit()+"| ");
		
		testDeck[11] = new Card(BlackJackConst.SUIT[1].charAt(0), 4, BlackJackConst.FOUR+" of "+BlackJackConst.SUIT[1]);
		testDeck[11].setSymbol(" |"+testDeck[11].getValue()+testDeck[11].getSuit()+"| ");
		
		testDeck[12] = new Card(BlackJackConst.SUIT[2].charAt(0), 5, BlackJackConst.FIVE+" of "+BlackJackConst.SUIT[2]);
		testDeck[12].setSymbol(" |"+testDeck[12].getValue()+testDeck[12].getSuit()+"| ");
		
		testDeck[13] = new Card(BlackJackConst.SUIT[2].charAt(0), 10, BlackJackConst.QUEEN+" of "+BlackJackConst.SUIT[2]);
		testDeck[13].setSymbol(" |"+BlackJackConst.QUEEN.charAt(0)+BlackJackConst.SUIT[2].charAt(0)+"| ");
		
		testDeck[14] = new Card(BlackJackConst.SUIT[0].charAt(0), 6, BlackJackConst.SIX+" of "+BlackJackConst.SUIT[0]);
		testDeck[14].setSymbol(" |"+testDeck[14].getValue()+testDeck[14].getSuit()+"| ");
		
		testDeck[15] = new Card(BlackJackConst.SUIT[1].charAt(0), 9, BlackJackConst.NINE+" of "+BlackJackConst.SUIT[1]);
		testDeck[15].setSymbol(" |"+testDeck[15].getValue()+testDeck[15].getSuit()+"| ");
	}
	
	public void initializeGame(){

		// Setting players
			players[0] = new Player();
			players[0].setName("Lemmy");
			
			players[1] = new Player();
			players[1].setName("Andrew");
			
			players[2] = new Player();
			players[2].setName("Billy");
			
			players[3] = new Player();
			players[3].setName("Carla");
	
	}
	

	
	// Deals the cards to the players and dealer
	public void dealCards(){
	
		dealer.addCard(testDeck[0]);
		dealer.addCard(testDeck[1]);
		
		//Lemmy
		players[0].addCard(testDeck[2]);
		players[0].addCard(testDeck[3]);
		players[0].addCard(testDeck[4]);
		
		//Andrew
		players[1].addCard(testDeck[5]);
		players[1].addCard(testDeck[6]);
		players[1].addCard(testDeck[7]);
		
		//Billy
		players[2].addCard(testDeck[8]);
		players[2].addCard(testDeck[9]);
		players[2].addCard(testDeck[10]);
		players[2].addCard(testDeck[11]);
		players[2].addCard(testDeck[12]);
		
		//Carla
		players[3].addCard(testDeck[13]);
		players[3].addCard(testDeck[14]);
		players[3].addCard(testDeck[15]);
			
	}
	
	
	// Initial check for dealer or player Blackjack
	public void checkBlackjack(){
		//System.out.println();

		if (dealer.isBlackjack() ) {
			System.out.println("Dealer has BlackJack!");
			for (int i =0; i < players.length; i++) {
				if (players[i].getTotal() == 21 ) {
					System.out.println(players[i].getName() + " wins");
					
				} else if(players[i].getTotal()<=21 && players[i].getNumberofCards()==5){
					System.out.println(players[i].getName() + " wins");

				}else {
					System.out.println(players[i].getName() + " looses");
				}	
			}
		} else {
			
			for (int i =0; i < players.length; i++) {
				if (players[i].getTotal() == 21 ) {
					System.out.println(players[i].getName() + " Win has blackjack!");
					
				}
			}
		}	
		
	}
	
	// This code calculates all possible outcomes
	public void findWiners() {
		System.out.println();
		//boolean playerIsWin = false ;
		for (int i = 0; i < players.length; i++) {
		
				if( players[i].getTotal() > 21 ) {
					System.out.println(players[i].getName() + " looses");
					System.out.println("Deal wins");
				
				} else if ( players[i].getTotal() == dealer.calculateTotal() ) {
					System.out.println(players[i].getName() + " wins");
					System.out.println("Deal loose");
					
				} else if ( (players[i].getTotal()<21) && (players[i].getNumberofCards()==5)) {
					System.out.println(players[i].getName() + " wins");
					System.out.println("Deal loose");
		        }else if ( players[i].getTotal() < dealer.calculateTotal() && dealer.calculateTotal() <= 21 ) {
					System.out.println(players[i].getName() + " has lost");
					System.out.println("Deal wins");
					
				} else if (players[i].getTotal() == 21) {
					System.out.println(players[i].getName() + " wins with blackjack!");
					System.out.println("Deal loose");
					
				} else {
					System.out.println(players[i].getName() + " wins");
					System.out.println("Deal loose");
				
				}
		}

	}
	
	// This prints the players hands
	public void printHands() {
		for (int i = 0; i < players.length; i++) {
		
		
			System.out.println(players[i].getName() + " has " + players[i].getHandString());
			
		}
		System.out.println();
		System.out.println("Dealer has " + dealer.getHandString());
	}
	
	// This code resets all hands
	public void clearHands() {
		for (int i = 0; i < players.length; i++) {
			players[i].clearHand();
		}
		dealer.clearHand();

	}
	
	public void endGame() {
		
		System.out.println("Thank you for playing!");
	}
	
	//testing deck
	public void prinDeck() {
		
		for (int i =0; i < testDeck.length; i++) {
			
			System.out.println(testDeck[i].getSymbol());
		}
		
	}
	/* 
	public static void main(String[] args) {
		
		Testcase d1 = new Testcase();
		//d1.prinDeck();
		
		Testcase mygame = new Testcase();
		
		mygame.initializeGame();
		mygame.dealCards();
		mygame.printHands();
		mygame.checkBlackjack();
		mygame.findWiners();
		//mygame.clearHands();
	}*/
}
