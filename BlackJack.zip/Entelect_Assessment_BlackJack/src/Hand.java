

public class Hand {
	
	private Card[] theHand = new Card[5];
	
	private int numberOfCards = 0;
	
	// Calculates the total of a hand and also decides whether ace is 1 or 11
	public int calculateTotal() {
		int total =0;
		boolean aceFlag = false;
		for (int i = 0; i < numberOfCards; i++) {
			int value = theHand[i].getValue();
			
		    if ( value == 1) {
				aceFlag = true;
			}
		    
			if (aceFlag && (total + 11 <= 21)) {
				total += 11;
			}else if(aceFlag && (total+value> 21)) {
				total += (value-10) ;
			}else {
			   total += value;
			}
		}
	
		return total;
	}
	public void addCard(Card card) {
		theHand[numberOfCards] = card;
		numberOfCards++;
	}
	
	public void clearHand() {
		numberOfCards = 0;
	}
	public String toString(){
		String str = " Showing ";
		String str2 = "\n";
		String str3 = "\n";
		
		for (int i = 0; i < numberOfCards; i++) {
		
				
				str+= theHand[i].getSymbol()+"	";
				str2+=  theHand[i].getDescription()+" ;";
			
		}
		   str3 += " Hand value: "+ calculateTotal();
		   
			return str+str2+str3+"\n";	
	}

}
