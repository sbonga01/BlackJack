

public class Dealer {

	private Hand hand = new Hand();
	
	// Determines if dealer has a blackjack
	public boolean isBlackjack(){
		if (hand.calculateTotal() == 21){
			return true;
		} else {
			return false;
		}
	}
	
	// This automates the dealer's play
	public void dealerPlay(Deck deck){
		System.out.println();
		while (hand.calculateTotal() <= 16) {
			
			hand.addCard(deck.nextCard());
			System.out.println("Dealer " + this.getHandString());
		} 
		if ( hand.calculateTotal() > 21) {
			System.out.println("Dealer Losses. " + this.getHandString());
		} else {
			System.out.println("Dealer stands. " + this.getHandString());
		}
	}
	
	// Adds a card o the dealer's hand
	public void addCard(Card card) {
		hand.addCard(card);

	}
	// Calculates the dealer's hand total
	public int calculateTotal() {
		return hand.calculateTotal();
	}
	
	// Clears the dealer's hand
	public void clearHand() {
		hand.clearHand();
	}
	public String getHandString() {
		String str = "Cards:" + hand.toString();

		return str;
	}
}
