import java.util.Scanner;


public class BlackJackGame {
	
	private Scanner ki = new Scanner(System.in);
	private int users; 
	private Player[] players;
	private Deck deck;
	private Dealer dealer = new Dealer();
	
	// Starts game and displays the rules
		public void initializeGame(){
			String names;

			
			// Gets the amount of players and creates them
			
				try {
				 System.out.print("How many people are playing (1-6)? ");
  			      String input ="";

                  if(ki.hasNextInt() ){
				    users = ki.nextInt();
				  }else {
					 //do {   
						 System.out.println("Wrong value entered please enter an interger");
						 System.out.print("How many people are playing (1-6)? "); 
						 users = ki.nextInt();
					 //} while (users > 6 || users < 0);
				   }
				 
				}catch(Exception e){
					System.out.println("Error in getting user input");
					e.printStackTrace();
				}

			

			players = new Player[users];
			deck = new Deck();

			// Asks for player names and assigns them
			for (int i = 0; i < users; i++) {
				System.out.print("What is player " + (i + 1) + "'s name? ");
				names = ki.next();
				players[i] = new Player();
				players[i].setName(names);
			}
		}
		
		// Shuffles the deck
		public void shuffle() {
			deck.shuffle();
			
		}
		
		// Deals the cards to the players and dealer
		public void dealCards(){
			for (int j = 0; j < 2; j++) {
				for (int i =0; i < users; i++) {
					
					players[i].addCard(deck.nextCard());
				
				}

				dealer.addCard(deck.nextCard());
			}
		}
		
		// Initial check for dealer or player Blackjack
		public void checkBlackjack(){
			//System.out.println();

			if (dealer.isBlackjack() ) {
				System.out.println("Dealer has BlackJack!");
				for (int i =0; i < users; i++) {
					if (players[i].getTotal() == 21 ) {
						System.out.println(players[i].getName() + " wins");
						
					} else if(players[i].getTotal()<=21 && players[i].getNumberofCards()==5){
						System.out.println(players[i].getName() + " wins");

					}else {
						System.out.println(players[i].getName() + " looses");
					}	
				}
			} else {
				
				for (int i =0; i < users; i++) {
					if (players[i].getTotal() == 21 ) {
						System.out.println(players[i].getName() + " Win has blackjack!");
						
					}
				}
			}	
			
		}
		
		// This code takes the user commands to hit or stand
					public void hitOrStand() {
						String command;
						char c;
						for (int i = 0; i < users; i++) {
							
								System.out.println();
								//System.out.println(players[i].getName() + " has " + players[i].getHandString());

							try {
								
										System.out.print(players[i].getName() + " Enter(H)to hit or (S) to stand? ");
										command = ki.next();
										c = command.toUpperCase().charAt(0);
										System.out.println(c);
									//} while ( ! ( c == 'H' || c == 'S' )||! ( c == 'h' || c == 's' ) );
									if ( c == 'H' ) {
										players[i].addCard(deck.nextCard());
										System.out.println(players[i].getName() + " has " + players[i].getHandString());
									}
								//} while (c != 'S' && players[i].getTotal() <= 21 );
							}catch(Exception e){
								System.out.println("Error in getting user input");
								e.printStackTrace();
							}

						}
					}
			
					// Code for the dealer to play
					public void dealerPlays() {
			
							dealer.dealerPlay(deck);
						
					}
					
					// This code calculates all possible outcomes
					public void findWiners() {
						System.out.println();
						//boolean playerIsWin = false ;
						for (int i = 0; i < users; i++) {
						
								if( players[i].getTotal() > 21 ) {
									System.out.println(players[i].getName() + " looses");
									System.out.println("Deal wins");
								
								} else if ( players[i].getTotal() == dealer.calculateTotal() ) {
									System.out.println(players[i].getName() + " wins");
									System.out.println("Deal loose");
									
								} else if ( (players[i].getTotal()<21) && (players[i].getNumberofCards()==5)) {
									System.out.println(players[i].getName() + " wins");
									System.out.println("Deal loose");
						        }else if ( players[i].getTotal() < dealer.calculateTotal() && dealer.calculateTotal() <= 21 ) {
									System.out.println(players[i].getName() + " has lost");
									System.out.println("Deal wins");
									
								} else if (players[i].getTotal() == 21) {
									System.out.println(players[i].getName() + " wins with blackjack!");
									System.out.println("Deal loose");
									
								} else {
									System.out.println(players[i].getName() + " wins");
									System.out.println("Deal loose");
								
								}
						}

					}
					
					// This prints the players hands
					public void printHands() {
						for (int i = 0; i < users; i++) {
						
						
							System.out.println(players[i].getName() + " has " + players[i].getHandString());
							
						}
						System.out.println();
						System.out.println("Dealer has " + dealer.getHandString());
					}
					
					// This code resets all hands
					public void clearHands() {
						for (int i = 0; i < users; i++) {
							players[i].clearHand();
						}
						dealer.clearHand();

					}
					
					// This decides to force the game to end when all players lose or lets players choose to keep playing or not
					public boolean playAgain() {
						String command;
						char c;
						Boolean playState = true;
						
							//do {
								System.out.println("");
								System.out.print("Do you want to play again (Y)es or (N)o? ");
								command = ki.next();
								c = command.toUpperCase().charAt(0);
							//} while ( (! ( c == 'Y' || c == 'N' )||(! ( c == 'y' || c == 'n'))) );
							
							if(c == 'N')
							{
								playState = false;
							}
						
						return playState;
					}
					
					// This is the endgame code for when all players are out of the game or players decide to stop playing
					public void endGame() {
							
						System.out.println("Thank you for playing!");
					}


}
