
public class Card {

	private char suit;
	private int value;
	private int value2;
	private String symbol;

	private String description;
	
	private Card() {

		suit = ' ';
		value = 0;
		description = "JOKER";


	}
	public Card(char newSuit, int newValue,String newDescription) {
		this.suit = newSuit;
		this.value = newValue;
		this.description = newDescription;
		
	}	public Card(char newSuit, int newValue,int newValue2,String newDescription) {
		this.suit = newSuit;
		this.value = newValue;
		this.value2 = newValue2;
		this.description = newDescription;
		
	}
	
	public int getValue2() {
		return value2;
	}
	public void setValue2(int value2) {
		this.value2 = value2;
	}
	public char getSuit() {
		return suit;
	}
	public void setSuit(char suit) {
		this.suit = suit;
	}
	public int getValue() {
		return value;
	}
	public void setValue(int value) {
		this.value = value;
	}
	public String getSymbol() {
		return symbol;
	}
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
}
